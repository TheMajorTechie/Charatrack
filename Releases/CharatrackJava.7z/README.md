# Charatrack
 Character activity tracker for creative writing.

Licensed under GNU GPLv3.
